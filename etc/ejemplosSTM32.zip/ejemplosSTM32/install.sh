#!/bin/sh
echo "*** Este script instala en un ambiento virtual de python lo necesario para crear modelos de TensorFlow ***"
echo "Instalando algunas cosas desde repositorio..."
sudo apt update
sudo apt install xxd
sudo apt install python3 python3-pip

echo "Se crea el ambiente virtual en el directorio donde se ejecuta este script ...."
python3 -m venv ./venv

echo "Instalando modulos con pip3..."
source ./venv/bin/activate #Con esto se activa el ambiente virtual, siempre es necesario hacerlo para correr los scripts de python

# Setup environment
pip3 install pandas numpy matplotlib tensorflow

echo "*** Fin, instalado lo necesario para generar un modelo de TensorFlow ***"
