#!/usr/bin/python3

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import tensorflow as tf
import seaborn as sns
import sklearn as sk
from sklearn import metrics
from keras.models import Sequential
from keras.layers import LSTM, Dense, Flatten, Dropout

print(f"TensorFlow version = {tf.__version__}\n")

# Set a fixed random seed value, for reproducibility, this will allow us to get
# the same random numbers each time the notebook is run
print("Configurando gestos...")
SEED = 1337
np.random.seed(SEED)
tf.random.set_seed(SEED)

# the list of gestures that data is available for
# ************************* Esto se debe modificar, aca van los gestos cuyos registros estan
# en archivos csv, aca abajo deben ir sin la extension
GESTURES = [
    "",
    "",
    "",
]

SAMPLES_PER_GESTURE = 49 #Esta es la ventana, tambien tiene que coincidir con la que esta en mainfuncions.h

NUM_GESTURES = len(GESTURES)

# create a one-hot encoded matrix that is used in the output
ONE_HOT_ENCODED_GESTURES = np.eye(NUM_GESTURES)

inputs = []
outputs = []

print("Leyendo archivos ...")
# read each csv file and push an input and output
for gesture_index in range(NUM_GESTURES):
  gesture = GESTURES[gesture_index]
  print(f"Processing index {gesture_index} for gesture '{gesture}'.")
  
  output = ONE_HOT_ENCODED_GESTURES[gesture_index]
  
  df = pd.read_csv(gesture + ".csv")
  
  # calculate the number of gesture recordings in the file
  num_recordings = int(df.shape[0] / SAMPLES_PER_GESTURE)
  
  print(f"\tThere are {num_recordings} recordings of the {gesture} gesture.")
  
  for i in range(num_recordings):
    tensor = []
    for j in range(SAMPLES_PER_GESTURE):
      index = i * SAMPLES_PER_GESTURE + j
      # normalize the input data, between 0 to 1:
      # - acceleration is between: -4 to +4
      # - gyroscope is between: -2000 to +2000 stm32: -500 a 500
      tensor += [
          (df['gX'][index] + 500) / 1000,
          (df['gY'][index] + 500) / 1000,
          (df['gZ'][index] + 500) / 1000
      ]

    inputs.append(tensor)
    outputs.append(output)
  #plot_activity(gesture, gesture_index,df)  

# convert the list to numpy array
inputs = np.array(inputs)
outputs = np.array(outputs)

print("Data set parsing and preparation complete.")

# Randomize the order of the inputs, so they can be evenly distributed for training, testing, and validation
# https://stackoverflow.com/a/37710486/2020087
num_inputs = len(inputs)
randomize = np.arange(num_inputs)
np.random.shuffle(randomize)

# Swap the consecutive indexes (0, 1, 2, etc) with the randomized indexes
inputs = inputs[randomize]
outputs = outputs[randomize]

# Split the recordings (group of samples) into three sets: training, testing and validation
TRAIN_SPLIT = int(0.6 * num_inputs)
TEST_SPLIT = int(0.2 * num_inputs + TRAIN_SPLIT)

inputs_train, inputs_test, inputs_validate = np.split(inputs, [TRAIN_SPLIT, TEST_SPLIT])
outputs_train, outputs_test, outputs_validate = np.split(outputs, [TRAIN_SPLIT, TEST_SPLIT])
#print("trains:"+str(len(inputs_train))+" tests: "+str(len(inputs_test))+" validate: "+str(len(inputs_validate)))
print("Data set randomization and splitting complete.")


# ************************* Esta parte es importante, se definen las capas, cuantas neuronas por capa y de que tipo *********************
# Build and train model
# build the model and train it
model = tf.keras.Sequential()
model.add(tf.keras.layers.Dense(50, activation='relu')) # relu is used for performance
#Insertar aca mas capas intermedias si considera necesarias
model.add(tf.keras.layers.Dense(NUM_GESTURES, activation='softmax')) # softmax is used, because we only expect one gesture to occur per input

model.compile(optimizer='rmsprop', loss='mse', metrics=['mae'])
history = model.fit(inputs_train, outputs_train, epochs=600, batch_size=1, validation_data=(inputs_validate, outputs_validate))
model.summary()

#Verify
# increase the size of the graphs. The default size is (6,4).
plt.rcParams["figure.figsize"] = (20,10)

# graph the loss, the model above is configure to use "mean squared error" as the loss function
# graph of mean absolute error
plt.plot(np.array(history.history['loss']), "b--", label = "Train loss")
plt.plot(np.array(history.history['mae']), "g--", label = "Training MAE")
plt.plot(np.array(history.history['val_loss']), "b-", label = "Validation loss")
plt.plot(np.array(history.history['val_mae']), "g-", label = "Validation MAE")
plt.title("Training session's progress over iterations")
plt.legend(loc='lower left')
plt.ylabel('Training Progress (Loss/MAE)')
plt.xlabel('Training Epoch')
plt.ylim(0) 
plt.show()

#Run with test data
# use the model to predict the test inputs
predictions = model.predict(inputs_test)

# print the predictions and the expected ouputs
print("predictions =\n", np.round(predictions, decimals=3))
print("actual =\n", outputs_test)

class_labels = GESTURES
max_test = np.argmax(outputs_test, axis=1)
max_predictions = np.argmax(predictions, axis=1)
confusion_matrix = metrics.confusion_matrix(max_test, max_predictions)
sns.heatmap(confusion_matrix, xticklabels = class_labels, yticklabels = class_labels, annot = True, linewidths = 0.1, fmt='d', cmap = 'YlGnBu')
plt.title("Confusion matrix", fontsize = 15)
plt.ylabel('True label')
plt.xlabel('Predicted label')
plt.show()


#Convert to tensorflow lite
# Convert the model to the TensorFlow Lite format without quantization
converter = tf.lite.TFLiteConverter.from_keras_model(model)
tflite_model = converter.convert()

#Econde model as header file
# Save the model to disk
open("gesture_model.tflite", "wb").write(tflite_model)

import os
basic_model_size = os.path.getsize("gesture_model.tflite")
print("Model is %d bytes" % basic_model_size)

os.system("rm model.cc")
os.system("echo \"#include model.h\" > model.cc")
os.system("echo \"extern const unsigned char girosmodel[] = {\" >> model.cc")
os.system("cat gesture_model.tflite | xxd -i      >> model.cc")
os.system("echo \"};\"                              >> model.cc")

import os
model_h_size = os.path.getsize("model.cc")
print(f"Model file, model.cc, is {model_h_size:,} bytes.")

